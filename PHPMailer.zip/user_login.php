<?php
include('../config.php');
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <title>使用者登入</title>
  </head>
  <body>
  

  <div class="half">
    <div class="bg order-1 order-md-2" style="background-image: url('images/bg_1.jpg');"></div>
    <div class="contents order-2 order-md-1">

      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-6">
            <div class="form-block">
              <div class="text-center mb-5">
              <h3>歡迎登入<strong>學餐系統</strong></h3>
              <!-- <p class="mb-4">Lorem ipsum dolor sit amet elit. Sapiente sit aut eos consectetur adipisicing.</p> -->
              </div>
              <!-- <form action="checkpwd.php" method="post">
                <div class="form-group first">
                  <label for="username">Username</label>
                  <input name='username' type="text" class="form-control" placeholder="your-email@gmail.com" >
                </div>
                <div class="form-group last mb-3">
                  <label for="password">Password</label>
                  <input id="password" type="password" class="form-control" placeholder="Your Password" >
                </div>
                
                <div class="d-sm-flex mb-5 align-items-center">
                  <label class="control control--checkbox mb-3 mb-sm-0"><span class="caption">Remember me</span>
                    <input type="checkbox" checked="checked"/>
                    <div class="control__indicator"></div>
                  </label>
                  <span class="ml-auto"><a href="#" class="forgot-pass">Forgot Password</a></span> 
                </div>

                <input type="submit" value="Log In" class="btn btn-block btn-primary">

              </form> -->
              <form action="checkpwd.php" method="post" name="myForm">
                <table width="40%" align="center">
                  <tr> 
                    <td align="center"> 



                        <div class="input-group input-group-dynamic mb-4">
                          <label class="form-label">帳號</label>
                          <input name='account' class="form-control" aria-label="帳號..." type="account" >
                        </div>
                      
                    </td>
                  </tr>
                  <tr> 
                    <td align="center"> 
                      <div class="input-group input-group-dynamic mb-4">
                        <label class="form-label">密碼</label>
                        <input name="password" class="form-control" aria-label="密碼..." type="password" >
                      </div>
                      
                    </td>
                  </tr>
                  <tr>
                    <td align="center"> 
                      <div class="text-center">
                        </div>
                      <input type="submit" value="登入"  class="btn bg-gradient-primary w-100 my-4 mb-2">      　 

                    </td>
                  </tr>
                </table>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    
  </div>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>